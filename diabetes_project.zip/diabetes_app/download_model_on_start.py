import os
import requests

MODEL_PATH = os.path.join(os.path.dirname(__file__), '..', 'diabetes_best_pipeline.pkl')
MODEL_PATH = os.path.abspath(MODEL_PATH)
MODEL_URL = "https://drive.google.com/uc?id=14J8Ol_6tVHWeMHstFA1wru3EUVbSpF2b"

def download_model():
    if not os.path.exists(MODEL_PATH):
        print("Downloading model...")
        r = requests.get(MODEL_URL, allow_redirects=True)
        with open(MODEL_PATH, 'wb') as f:
            f.write(r.content)
        print("Model downloaded successfully!")
    else:
        print("Model already exists.")
