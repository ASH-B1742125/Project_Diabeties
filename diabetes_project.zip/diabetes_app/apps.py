from django.apps import AppConfig

class DiabetesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'diabetes_app'

    def ready(self):
        # Runs once when Django starts
        from .download_model_on_start import download_model
        download_model()
