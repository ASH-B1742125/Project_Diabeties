import os
import pandas as pd
from django.shortcuts import render
from django.conf import settings
import joblib

MODEL_PATH = os.path.join(settings.BASE_DIR, "diabetes_app", "diabetes_best_pipeline.pkl")
model = None
if os.path.exists(MODEL_PATH):
    try:
        model = joblib.load(MODEL_PATH)
    except Exception as e:
        model = None

def home(request):
    return render(request, "index.html")

def predict(request):
    result = None
    if request.method == "POST":
        try:
            if model is None:
                raise FileNotFoundError("Model not found or failed to load. Run create_model.py locally to create diabetes_best_pipeline.pkl.")
            # Collect inputs
            age = float(request.POST.get("age"))
            gender = request.POST.get("gender")
            hypertension = int(request.POST.get("hypertension"))
            heart_disease = int(request.POST.get("heart_disease"))
            smoking_history = request.POST.get("smoking_history")
            bmi = float(request.POST.get("bmi"))
            HbA1c_level = float(request.POST.get("HbA1c_level"))
            blood_glucose_level = float(request.POST.get("blood_glucose_level"))

            # Build DataFrame matching training columns
            sample = pd.DataFrame([{
                "gender": gender,
                "age": age,
                "hypertension": hypertension,
                "heart_disease": heart_disease,
                "smoking_history": smoking_history,
                "bmi": bmi,
                "HbA1c_level": HbA1c_level,
                "blood_glucose_level": blood_glucose_level
            }])

            pred = int(model.predict(sample)[0])
            proba = None
            if hasattr(model, "predict_proba"):
                proba = float(model.predict_proba(sample)[0][1]) * 100.0

            if pred == 1:
                result = f"⚠️ Likely Diabetic (Risk: {proba:.2f}%)" if proba is not None else "⚠️ Likely Diabetic"
            else:
                result = f"✅ Not Diabetic (Risk: {proba:.2f}%)" if proba is not None else "✅ Not Diabetic"

        except Exception as e:
            result = f"Error: {str(e)}"

    return render(request, "predict.html", {"result": result})
