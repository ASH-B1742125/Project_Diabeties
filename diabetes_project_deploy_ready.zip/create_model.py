import os
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
import joblib

CSV_PATH = "diabetes_prediction_dataset.csv"
df = pd.read_csv(CSV_PATH)

TARGET = "diabetes"
X = df.drop(columns=[TARGET])
y = df[TARGET].astype(int)

numeric_cols = X.select_dtypes(include=["int64", "float64"]).columns.tolist()
categorical_cols = X.select_dtypes(include=["object"]).columns.tolist()

numeric_transformer = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())])
categorical_transformer = Pipeline([("imputer", SimpleImputer(strategy="most_frequent")), ("onehot", OneHotEncoder(handle_unknown="ignore", sparse=False))])

preprocessor = ColumnTransformer(transformers=[("num", numeric_transformer, numeric_cols), ("cat", categorical_transformer, categorical_cols)])

clf = RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1)
pipeline = Pipeline([("preprocessor", preprocessor), ("classifier", clf)])

pipeline.fit(X, y)

os.makedirs("diabetes_app", exist_ok=True)
MODEL_PATH = os.path.join("diabetes_app", "diabetes_best_pipeline.pkl")
joblib.dump(pipeline, MODEL_PATH)
print("Saved pipeline to:", MODEL_PATH)
